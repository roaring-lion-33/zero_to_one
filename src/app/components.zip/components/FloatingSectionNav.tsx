'use client';

import { useEffect, useState, useRef } from 'react';
import { motion } from 'framer-motion';
import clsx from 'clsx';

const sections = [
  { id: '#hero', label: 'Top' },
  { id: '#who-its-for', label: "Who It's For" },
  { id: '#what-you-get', label: 'What You Get' },
  { id: '#how-we-work', label: 'How We Work' },
  { id: '#launch-plan', label: 'The Plan' },
  { id: '#case-studies', label: 'Case Study' },
  { id: '#founder', label: 'About Frank' },
  { id: '#contact', label: 'Contact' },
];

export default function FloatingSectionNav() {
  const [activeId, setActiveId] = useState<string>('');
  const [collapsed, setCollapsed] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  let lastScrollY = 0;

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.find((entry) => entry.isIntersecting);
        if (visible) setActiveId(`#${visible.target.id}`);
      },
      {
        rootMargin: '-40% 0% -40% 0%',
        threshold: 0.1,
      }
    );

    sections.forEach(({ id }) => {
      const el = document.querySelector(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const scrollingDown = currentScrollY > lastScrollY;

      if (scrollingDown) {
        setCollapsed(true);
      } else {
        setCollapsed(false);
      }

      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        setCollapsed(false);
      }, 1200);

      lastScrollY = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <motion.div
      animate={{ opacity: collapsed ? 0 : 1, y: collapsed ? -10 : 0 }}
      transition={{ duration: 0.3 }}
      className="fixed top-1/2 -translate-y-1/2 right-4 z-40 hidden lg:flex flex-col gap-3"
    >
      {sections.map(({ id, label }) => (
        <a
          key={id}
          href={id}
          onClick={(e) => handleClick(e, id)}
          className="group relative"
          aria-label={label}
        >
          <span
            className={clsx(
              'block h-3 w-3 rounded-full transition-all duration-300',
              activeId === id
                ? 'bg-[var(--accent)] scale-125'
                : 'bg-gray-300 hover:bg-gray-400'
            )}
          />
          <motion.span
            initial={{ opacity: 0, x: 5 }}
            whileHover={{ opacity: 1, x: 10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-7 top-1/2 -translate-y-1/2 whitespace-nowrap text-xs text-[#3b82f6] opacity-0 group-hover:opacity-100"
          >
            {label}
          </motion.span>
        </a>
      ))}
    </motion.div>
  );
}
